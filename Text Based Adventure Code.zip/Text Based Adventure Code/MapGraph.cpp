#include <vector>
#include <queue>
#include <iostream>
#include "MapGraph.hpp"

using namespace std;
void Graph::addVertex(string n){
    bool found = false;
    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i]->name == n){
            found = true;
        }
    }
    if(found == false){
        vertex * v = new vertex;
        v->name = n;
        vertices.push_back(v);
    }
}
//**********************************************************************************************************************************
void Graph::addEdge(string v1, string v2){
    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i]->name == v1){
            for(int j = 0; j < vertices.size(); j++){
                if(vertices[j]->name == v2 && i != j){
                    adjVertex av;
                    av.v = vertices[j];
                    vertices[i]->adj.push_back(av);
                    //another vertex for edge in other direction
                    adjVertex av2;
                    av2.v = vertices[i];
                    vertices[j]->adj.push_back(av2);
                }
            }
        }
    }
}
//**********************************************************************************************************************************
void Graph::displayEdges(){
    for(unsigned int x = 0; x < vertices.size(); x++){
        cout << vertices[x]->name << " --> ";
        for(unsigned int i = 0; i < vertices[x]->adj.size(); i++){
            cout << " " << vertices[x]->adj[i].v->name;
        }
        cout << endl;
    }
}
//**********************************************************************************************************************************
vertex* Graph::search(string k){
    for(unsigned int i=0; i<vertices.size(); i++){
        if(vertices[i]->name == k){
            return vertices[i];
        }
    }
    return NULL;
}

vertex* Graph::searchAdj(string k,vertex* Current){
    for(unsigned int i=0; i<Current->adj.size(); i++){
        if(Current->adj[i].v->name == k){
            return Current->adj[i].v;
        }
    }
    return NULL;
}

int Graph::searchItems(string k,vertex* Current){
    for(unsigned int i=0; i<Current->items.size(); i++){
        if(Current->items[i] == k){
            return i;
        }
    }
    return -1;
}
//**********************************************************************************************************************************
void DFTraversal(vertex *n){
    n->visited = true;

    for(unsigned int x = 0; x < n->adj.size(); x++ )
    {
        // TODO
        if(n->adj[x].v && n->adj[x].v->visited == false){
        //cout << n->adj[x].v->key << endl;
            DFTraversal(n->adj[x].v);
        }
    }

}

int Graph::getConnectedComponents(){
    int components = 0;
    for(unsigned int x=0; x<vertices.size(); x++){
      if(vertices[x]->visited == false){
          components++;
          DFTraversal(vertices[x]);
      }
    }
    return components;
}
//**********************************************************************************************************************************
vertex* Graph::initialRoom(){
    return vertices[0];
}
