#include <iostream>
#include <String>
#include <Vector>
#include "BST.hpp"

using namespace std;
#define COUNT 10
/**
Create a node with key as data
**/

Node* BST:: createNode(int data)
{
    Node* newNode = new Node;
    newNode->key = data;
    newNode->left = NULL;
    newNode->right = NULL;
	newNode->name = "";
    return newNode;
}

BST::BST()
{
	root = NULL;
}

/**
parameterized constructor. It will create the root and put the data in the root.
**/

BST::BST(int data)
{
    root = createNode(data);
    cout<< "New tree created with "<<data<<endl;
}

/**
Destructor
**/

BST::~BST(){
     destroyNode(root);
}


Node* BST::getRoot(){
    return root;
}

 /**
 This function will destroy the subtree rooted at currNode.
 Think about in what order should you destroy. POSTORDER. or right-left-root
 **/
void BST:: destroyNode(Node *currNode){
     if(currNode!=NULL)
     {
         destroyNode(currNode->left);
         destroyNode(currNode->right);

         delete currNode;
         currNode = NULL;
     }
 }

/*
Prints a binary tree in a 2D fashion.
Note: The image of the tree is left rotated by 90 degrees.
*/
void BST::print2DUtilHelper(Node *currNode, int space)
{
    // Base case
    if (currNode == NULL)
        return;

    // Increase distance between levels
    space += COUNT;

    // Process right child first
    print2DUtilHelper(currNode->right, space);

    // Print current node after space
    // count
    printf("\n");
    for (int i = COUNT; i < space; i++)
        printf(" ");
	if(currNode->key >= 0){
    printf("%d, %s\n", currNode->key, currNode->name.c_str());
	} else {
	cout << "Slot " << -1*currNode->key << ": Empty";
	}
	//cout << currNode->key << " " << currNode->name <<endl;

    // Process left child
    print2DUtilHelper(currNode->left, space);
}

void BST::print2DUtil( int space)
{
  print2DUtilHelper(root, space);
  cout <<endl;
}



//---------------------------- INSERT NODE IN THE TREE --------------------------------------

/**
This function will add the data in the tree rooted at currNode.
We will call this function from addNode.
**/

Node* BST:: addNodeHelper(Node* currNode, Node* newNode)
{
    if(currNode == NULL){
        return createNode(newNode->key);
    }
    else if(currNode->key < newNode->key){
        currNode->right = addNodeHelper(currNode->right,newNode);
    }
    else if(currNode->key > newNode->key){
        currNode->left = addNodeHelper(currNode->left,newNode);
    }
    return currNode;

}


void BST:: addNode(Node* newNode)
{
	//cout << "Adding node..." <<endl;
    root = addNodeHelper(root, newNode);
    //cout<<newNode->key<<" has been added"<<endl;
}

//-----------------------------------------PRINT TREE (INORDER TRAVERSAL)--------------------------------

/** This function will traverse the tree in-order and print out the node elements.
printTree() function will call this function.
**/

void BST:: printTreeHelper(Node* currNode){
     if(currNode)
     {
        printTreeHelper( currNode->left);
        cout << " "<< currNode->key;
        printTreeHelper( currNode->right);
     }
 }

void BST:: printTree(){
     printTreeHelper(root);
     cout<<endl;
}

 //------------------------------------------------SEARCH A KEY------------------------------------------
 /** This function will search the data in a tree
     We will call this function from searchKey.
 **/

Node* BST::searchKeyHelper(Node* currNode, int data){
    if(currNode == NULL)
        return NULL;

    if(currNode->key == data)
        return currNode;

    if(currNode->key > data)
        return searchKeyHelper(currNode->left, data);

    return searchKeyHelper (currNode->right, data);
}

// This function will return whether a key is in the tree
bool BST::searchKey(int key){
    Node* tree = searchKeyHelper(root, key);
    if(tree != NULL) {
        return true;
    }
    cout<<"Key not present in the tree"<<endl;
    return false;
}

//--------------------------- Get Max and Min value Node ------------------------------------------------

Node* BST::getMaxValueNode(Node* currNode){
    if(currNode->right == NULL){
        return currNode;
    }
    return getMaxValueNode(currNode->right);
}

Node* BST::getMinValueNode(Node* currNode){

    if(currNode->left == NULL){
      return currNode;
    }
    return getMinValueNode(currNode->left);
}


//--------------------------- Delete a Node ------------------------------------------------

// This function deletes the Node with 'value' as it's key. This is to be called inside removeRange() function
Node* BST::deleteNode(Node *currNode, int value)
{

  if(currNode == NULL)
  {
    return NULL;
  }
  else if(value < currNode->key)
  {
    currNode->left = deleteNode(currNode->left, value);
  }
  else if(value > currNode->key)
  {
    currNode->right = deleteNode(currNode->right, value);
  }
  // We found the node with the value
  else
  {
    //TODO Case : No child
    if(currNode->left == NULL && currNode->right == NULL)
    {
		Node* temp = NULL;
		delete currNode;
		return temp;
    }
    //TODO Case : Only right child
    else if(currNode->left == NULL)
    {   
		Node* temp = currNode;
		currNode = currNode->right;
		// delete currNode;
		delete temp;
    }
    //TODO Case : Only left child
    else if(currNode->right == NULL)
    {
		Node* temp = currNode;
		currNode = currNode->left;
		// delete currNode;
		delete temp;
    }
    //TODO Case: Both left and right child
    else
    {
      ///Replace with Minimum from right subtree
		Node* minVal = getMinValueNode(currNode->right);
		int minValKey = minVal->key;
		currNode->key = minValKey;
		currNode->right = deleteNode(currNode->right, minValKey);
		//currNode->key = minValKey;
		delete minVal;
		//return currNode;
    }

  }
return currNode;
}



void BST::removeRange(int low, int high)
{
  for(int i=low; i<=high; i++){
    root=deleteNode(root,i);
  }
}


void BST::createCompareTree(string items[]){
	Node* newNode = new Node;
	newNode->left = NULL;
	newNode->right = NULL;
	int Total = 0;
	for(int i=0; i<7; i++){ //For all jewels
		newNode->name = items[i];
		Total = 0;
		for(int k=0; k<items[i].length(); k++){
            Total += items[i][k];
        }
		newNode->key = Total;
	addNode(newNode); // add according to ASCII
	}
}

void BST::createEmptyTree(string items[]){
	createCompareTree(items);
	root->key = -1;
	root->left->key = -2;
	root->right->key = -3;
	root->left->left->key = -4;
	root->left->right->key = -5;
	root->right->left->key = -6;
	root->right->right->key = -7;
}

bool BST::insertGem(int slot, string item){
	int ASCII = 0;
	for(int i=0; i<item.length(); i++){ //Calculate ASCII value of item
		ASCII += item[i];
	}

	switch(slot){
		case 1:
			if(root->name != ""){
				cout << "This slot is already full. Remove the gem or try another slot." <<endl;
				return false;
			}
			root->name = item;
			root->key = ASCII;
			return true;
		case 2:
			if(root->left->name != ""){
				cout << "This slot is already full. Remove the gem or try another slot." <<endl;
				return false;
			}
			root->left->name = item;
			root->left->key = ASCII;
			return true;
		case 3:
			if(root->right->name != ""){
				cout << "This slot is already full. Remove the gem or try another slot." <<endl;
				return false;
			}
			root->right->name = item;
			root->right->key = ASCII;
			return true;
		case 4:
			if(root->left->left->name != ""){
				cout << "This slot is already full. Remove the gem or try another slot." <<endl;
				return false;
			}
			root->left->left->name = item;
			root->left->left->key = ASCII;
			return true;
		case 5:
			if(root->left->right->name != ""){
				cout << "This slot is already full. Remove the gem or try another slot." <<endl;
				return false;
			}
			root->left->right->name = item;
			root->left->right->key = ASCII;
			return true;
		case 6:
			if(root->right->left->name != ""){
				cout << "This slot is already full. Remove the gem or try another slot." <<endl;
				return false;
			}
			root->right->left->name = item;
			root->right->left->key = ASCII;
			return true;
		case 7:
			if(root->right->right->name != ""){
				cout << "This slot is already full. Remove the gem or try another slot." <<endl;
				return false;
			}
			root->right->right->name = item;
			root->right->right->key = ASCII;
			return true;
		default:
			cout << "Please insert a valid slot" <<endl;
			return false;
	}
}

string BST::removeGem(int slot){
	string toReturn = "";
	switch(slot){
		case 1:
			toReturn = root->name;
			root->name = "";
			root->key = -1*slot;
			return toReturn;
			break;
		case 2:
			toReturn = root->left->name;
			root->left->name = "";
			root->left->key = -1*slot;
			return toReturn;
			break;
		case 3:
			toReturn = root->right->name;
			root->right->name = "";
			root->right->key = -1*slot;
			return toReturn;
			break;
		case 4:
			toReturn = root->left->left->name;
			root->left->left->name = "";
			root->left->left->key = -1*slot;
			return toReturn;
			break;
		case 5:
			toReturn = root->left->right->name;
			root->left->right->name = "";
			root->left->right->key = -1*slot;
			return toReturn;
			break;
		case 6:
			toReturn = root->right->left->name;
			root->right->left->name = "";
			root->right->left->key = -1*slot;
			return toReturn;
			break;
		case 7:
			toReturn = root->right->right->name;
			root->right->right->name = "";
			root->right->right->key = -1*slot;
			return toReturn;
			break;
		default:
			cout << "Please insert a valid slot" <<endl;
			return toReturn;
			break;
	}
}



vector<int> BST::treeToVector(){
	vector<int> toReturn;

	toReturn.push_back(root->key);
	toReturn.push_back(root->left->key);
	toReturn.push_back(root->right->key);
	toReturn.push_back(root->left->left->key);
	toReturn.push_back(root->left->right->key);
	toReturn.push_back(root->right->left->key);
	toReturn.push_back(root->right->right->key);

	return toReturn;
}