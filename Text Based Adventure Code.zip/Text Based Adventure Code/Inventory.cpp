// CPP program to implement hashing with chaining
#include<iostream>
#include "Inventory.hpp"


using namespace std;

Inventory::Inventory(int bsize)
{
    tableSize= bsize;
    //string table[tableSize];
	for (int i = 0; i < bsize; i++) {
		table.push_back("");
	}
}

int Inventory::getTableSize() {

	return tableSize;

}

//function to calculate hash function
unsigned int Inventory::hashFunction(string input)
{
	int key = 0;
	for (int i = 0; i < input.length(); i++)
	{
		key += (int)input[i];
	}
    return (key % tableSize);
}

//function to search by name
string Inventory::searchItem(string name)
{
    //Compute the index by using the hash function
    int index = hashFunction(name);
	string temp = table[index];

	if(temp == name) {
		return temp;
	}
	return "";
}

//function to search by number
string Inventory::searchItemNum(int num)
{
	if (num >=0 && num <=tableSize-1) {
		return table[num];
	} else {
		return "";
	}
}

//function to insert
bool Inventory::insertItem(string input)
{
		int hash = hashFunction(input);
		if (table[hash] == "") {
			table[hash] = input;
		} else {
			cout << "Hash location " << hash << " is already filled with " << table[hash] << "." << endl;
			cout << "Please drop the " << table[hash] << " before trying to pick up the " << input << "." << endl;
			return false;
		}
		return true;

}

int Inventory::deleteItem(int num) {
	string temp = searchItem(table[num]);
	if (temp != "") {
		table[num] = "";
		return 1;
	}
	else {
		return 0;
	}

}

string Inventory::getName(int hash) {
	return table[hash];
}

// function to display hash table
void Inventory::printTable()
{
	for (int i = 0; i < tableSize; i++) {
		cout << i << "|| ";
		cout << table[i] << endl;
	}

 }
