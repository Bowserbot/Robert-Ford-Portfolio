#ifndef INVENTORY_HPP
#define INVENTORY_HPP

#include <string>
#include <vector>


using namespace std;

class Inventory
{
    int tableSize;  // No. of buckets (linked lists)
	vector<string> table;

public:
	Inventory(int bsize);  // Constructor

	int getTableSize();

    // inserts a key into hash table
    bool insertItem(string input);

    // hash function to map values to key
    unsigned int hashFunction(string input);

	// deletes an entry from the table
	int deleteItem(int num);

	// get name at location
	string getName(int hash);

    void printTable();

    string searchItem(string key);

	string searchItemNum(int num);
};

#endif
