#include<iostream>
#include<vector>
#include"MapGraph.cpp"
#include "Inventory.cpp"
#include "BST.cpp"

void DisplayRooms(vertex* CurrentRoom){
    cout << endl;
    cout << "---------------------------" << endl;
    cout << "Where would you like to go?" << endl;
    cout << "---------------------------" << endl;
    for(int x=0; x<CurrentRoom->adj.size();x++){
        cout << CurrentRoom->adj[x].v->name;
        if(CurrentRoom->adj[x].v->locked == true){
            cout <<" (Locked)";
        }
        cout << endl;
    }
    cout << endl;
}
void DisplayRoomInventory(vertex* CurrentRoom){
    cout << endl;
    cout << "---------------------------" << endl;
    int Total = 0;
    for(int x=0; x<CurrentRoom->items.size();x++){
		Total = 0;
        cout << CurrentRoom->items[x];
        for(int i=0; i<CurrentRoom->items[x].size(); i++){
            Total += CurrentRoom->items[x][i];
        }
        cout << " " << Total;
        cout << endl;
    }
    cout << endl;
}
void DisplayPlayerInventory(Inventory Inv){
	vector<item> sortedInv;
	item newItem;
	item temp;
	cout << endl;
	cout << "---------------------------" << endl;
	int Total = 0;
	for (int x = 0; x < Inv.getTableSize(); x++) { //sort inventory
		if (Inv.searchItemNum(x) != "") { //for every item in the inventory
			newItem.name = Inv.searchItemNum(x); //Set name of newItem
			//cout << Inv.searchItemNum(x);
			Total = 0;
			for (int i = 0; i < Inv.searchItemNum(x).size(); i++) { //calculate ASCII value of item
				Total += Inv.searchItemNum(x)[i];
			}
			newItem.value = Total;
			//cout << Total << endl;
			sortedInv.push_back(newItem);
		}
	}
	cout << endl;

	for (int i=0; i < sortedInv.size(); i++) {
		for (int k = 0; k < sortedInv.size() - 1; k++) {
			if (sortedInv[k].value > sortedInv[k+1].value) {
				temp = sortedInv[k];
				sortedInv[k] = sortedInv[k + 1];
				sortedInv[k + 1] = temp;
			}
		}

	}

	for (int i=0; i < sortedInv.size(); i++) {
		cout << sortedInv[i].name;
		cout << " " << sortedInv[i].value;
		cout << endl;
	}
}

void DeleteFromRoom(string item,vertex* Room){
    for(int x=0; x<Room->items.size();x++){
        if(Room->items[x] == item){
            Room->items.erase(Room->items.begin()+x);
        }
    }
}

int checkInt(string input){
	if(input == ""){
		return 0;
	}
	for(int i=0; i<input.length(); i++){
		if(input[i] < 48 || input[i] > 57){
			return 0;
		}
	}
	return 1;
}


int main()
{
	//Establish BST puzzle
	bool End = false;
	BST tree;
	BST compare; // Tree to compare to see if puzzle correctly solved
	BST puzzleTree;
	string gems[] = {"Diamond", "Pearl", "Amethyst", "Ruby", "Emerald", "Sapphire", "Magic Crystal"};
	compare.createCompareTree(gems);
	puzzleTree.createEmptyTree(gems);
	//puzzleTree.print2DUtil(1);
	vector<int> compareTreeVector;
	vector<int> puzzleTreeVector;
	//Establish Inventory
	//system("CLS");
	string in;
	cout << "---------------------------" << endl;
    cout << endl;
	cout << "How big would you like your inventory to be?" << endl;
	cout << "This will also determine the modulo used to store items." << endl;
	cout << "Example: item number % your input = where your item is stored." << endl;
	cout << endl;
    cout << "---------------------------" << flush << endl;
    cout << endl;
	getline(cin, in);
	while(checkInt(in) == 0){
		cout << "Please enter a valid integer" <<endl;
		getline(cin, in);
	}
	system("CLS");
	int invSize = stoi(in);
	int Score = 0;
	bool seen = false;
	Inventory Inv(invSize);
    //This is establishing our map connections and the variable to be used in the UI part
    Graph Map;
    vertex* CurrentRoom;
    Map.addVertex("Entrance"); //items and text done
    Map.addVertex("Study"); //items and text done
    Map.addVertex("Dining Room"); //items and text done
    Map.addVertex("Foyer"); //items and text done
    Map.addVertex("Back Door"); //text done
    Map.addVertex("Shed"); //text done
    Map.addVertex("Basement"); //text done
    Map.addVertex("Gate"); //text done
    Map.addVertex("Escape"); //text done
    Map.addVertex("Garden"); //text done
    Map.addVertex("Fountain"); //text done
        Map.addEdge("Entrance","Study");
        Map.addEdge("Study","Dining Room");
        Map.addEdge("Dining Room","Foyer");
        Map.addEdge("Foyer","Entrance");
        Map.addEdge("Foyer","Back Door");
        Map.addEdge("Back Door","Garden");
        Map.addEdge("Back Door","Gate");
        Map.addEdge("Gate","Escape");
        Map.addEdge("Back Door","Shed");
        Map.addEdge("Shed","Basement");
        Map.addEdge("Basement","Foyer");
        Map.addEdge("Garden","Fountain");
    CurrentRoom = Map.initialRoom();
    string Shovel = "Shovel";
    string Wand = "Wand";
    string Bottle = "Bottle of Acid";
    string Candle = "Candle";
    string Scythe = "Scythe";
    string Ladder = "Step Ladder";
    string Bat = "Bat";
    string Glass = "Glass";
    string Flashlight = "Flashlight";
    string Knife = "Knife";
    string Ruby = "Ruby";
    string Sapphire = "Sapphire";
    string Emerald = "Emerald";
    string Diamond = "Diamond";
    string Amethyst = "Amethyst";
    string Magic = "Magic Crystal";
    string Pearl = "Pearl";
    Map.search("Back Door")->locked = true;
    Map.search("Escape")->locked = true;
    Map.search("Basement")->locked = true;
    Map.search("Shed")->itemHere = true;
    Map.search("Shed")->items.push_back(Shovel);
    Map.search("Shed")->items.push_back(Candle);
    Map.search("Shed")->items.push_back(Scythe);
    Map.search("Study")->itemHere = true;
    Map.search("Study")->items.push_back(Wand);
    Map.search("Study")->items.push_back(Bottle);
    Map.search("Basement")->itemHere = true;
    Map.search("Basement")->items.push_back(Bat);
    Map.search("Dining Room")->itemHere = true;
    Map.search("Dining Room")->items.push_back(Knife);
    string input = "";
    cout << "---------------------------" << endl;
    cout << endl;
    bool key = true;
    //this block of code is for testing the final puzzle
		/*CurrentRoom = Map.search("Gate");
		Inv.insertItem("Ruby");
		Inv.insertItem("Sapphire");
		Inv.insertItem("Emerald");
		//Inv.insertItem("Diamond");
		Map.search("Gate")->items.push_back(Diamond);
		Inv.insertItem("Amethyst");
		Inv.insertItem("Magic Crystal");
		Inv.insertItem("Pearl");*/
    //this is the part where the actual UI Starts
    while(key==true){
        //these if statements hold the individual text that is displayed upon going into any room and is determined by Room name
        if(CurrentRoom->name == "Entrance"){
            cout << "Welcome to the Entrance of the maze!" << endl;
            cout << "A bright light comes in through a window higher on the wall" << endl;
            cout << "and a painting of a sun with a face is underneath it." << endl;
        }
        if(CurrentRoom->name == "Study"){
            cout << "Inside this room there are several arcane objects of importance....and some books and stuff but like c'mon." << endl;
            if(CurrentRoom->puzSolved == false){
                cout << "It's dark behind one of the book cases, there could also be something there." << endl;
            }
        }
        if(CurrentRoom->name == "Foyer"){
            cout << "This is an extremely large room with an ornate chandelier hanging from the ceiling." << endl;
			cout << "There is a staircase down to the basement and a door that leads outside." << endl;
        }
        if(CurrentRoom->name == "Dining Room"){
            cout << "You walk into a extremely well kept Dining room" << endl;
            cout << "It looks like someone was preparing seafood in here, there are a few un-opened oysters on the counter top." << endl;
            cout << "Inside the cupboard there is a hidden safe door that has a lock on the handle." << endl;
        }
        if(CurrentRoom->name == "Back Door"){
            cout << "You walk through the door and find yourself in a gated courtyard." << endl;
            cout << "There is a shed and a well kept garden in this courtyard." << endl;
        }
        if(CurrentRoom->name == "Shed"){
            cout << "The shed is very dusty and shows signs that it hasn't been used in a long time." << endl;
            if(CurrentRoom->itemHere == true){
                cout << "There are a variety of tools in here that look useful" << endl;
            }
            cout << "There is also a hatch in the corner with some kind of magic symbol on it, it looks pretty old." << endl;
        }
        if(CurrentRoom->name == "Basement"){
            if(seen == false){
                cout << "It's extremely dark in the basement, but you think there is something down here." << endl;
            }else{
                cout << "The basement is pretty cold, the walls are made of concrete and there is a mound of dirt in the corner." << endl;
            }
            cout << "There's a railing that leads from the stairs on one side of the room to the ladder on the other." << endl;
        }
        if(CurrentRoom->name == "Gate"){
            cout << "This is the final puzzle." << endl;
            cout << endl;
            cout << "The gate out of here has a design going across it that has several slots in it." << endl;
            cout << "It's your job to fill each slot with a different gem and balance them out," << endl;
            cout << "as you go from the bottom to the top the numbers that count the score for their name should go up." << endl;
            cout << endl;
            cout << "use the command 'remove' to take items out of the Gate and 'use' the gems to insert them." << endl;
            cout << endl;
            cout << "Good Luck!" << endl;
			puzzleTree.print2DUtil(1);
        }
        if(CurrentRoom->name == "Escape"){
            cout << "As the gate opens you find yourself on a cobblestone path with amber fields of grain on either side." << endl;
            cout << "You've finally escaped!" << endl;
            cout << endl;
            cout << "Congratulations!" << endl;
            cout << endl;cout << endl;cout << endl;
            cout << "This game was made by Bobby Ford and Joshua Dinerman for their Data Structure's choose your own project :)" << endl;
			cout << "---------------------------" << flush << endl;
			cout << endl;
			cout << "Your score is: " << Score;
			if(Score != 0){
                cout << " Try to be as low as possible by working out your inventory and not guessing where items are!"<< endl;
			}
			cout << endl;
			if(Score == 0){
                cout << "Congratulations! you got a perfect score!" << endl;
			}
			End = true;
			break;
        }
        if(CurrentRoom->name == "Garden"){
            cout << "You walk into a surprisingly well kept garden with flowers in bloom all around you." << endl;
            cout << "There is a fountain in the middle of the garden." << endl;
            if(CurrentRoom->puzSolved == false){
                cout << "A chest locked up tight with vines sits in the corner of the Garden." <<endl;
            }
        }
        if(CurrentRoom->name == "Fountain"){
            cout << "This fountain is an ornately carved marble fountain";
            if(CurrentRoom->puzSolved == false){
                cout << "it has something that is shining in the top." << endl;
            }else{
                cout << "." << endl;
            }
        }

        //this is the part where the player is prompted with all the rooms that they are able to go to
        DisplayRooms(CurrentRoom);
        getline(cin,input);
        while(Map.searchAdj(input,CurrentRoom) == NULL || Map.searchAdj(input,CurrentRoom)->locked == true){
            system("CLS");
            cout << "---------------------------" << flush << endl;
            cout << endl;
            if(Map.searchAdj(input,CurrentRoom) == NULL || Map.searchAdj(input,CurrentRoom)->locked == false){
                if(input != "take" && input != "quit" && input != "use" && input != "drop" && input != "help" && input != "remove"){
                    cout << "Uh oh, that's not an available room" << endl;
                }else if(input == "take"){
                    cout << "What will you take?" << endl;
                    DisplayRoomInventory(CurrentRoom);
                    getline(cin,input);
                    //text for grabbing specific items will go in here
					if (Map.searchItems(input, CurrentRoom) != -1) {
						system("CLS");
						if(Inv.insertItem(input) == true){
							cout << "You take the " << input << flush << endl;
							//Delete from room inventory (requires delete function for room)
							DeleteFromRoom(input,CurrentRoom);
						}
					}
					else {
						system("CLS");
                        cout << "You don't take anything" << flush << endl;
					}

				}
				else if (input == "use") {
					cout << "What will you use?" << endl;
					DisplayPlayerInventory(Inv);
					cout << endl;
					cout << "Enter the number of the inventory slot you want to use." << endl;
                    cout << "you currently have: " << invSize << " slots" << endl;
					getline(cin, input);
					while(checkInt(input) == 0){
						cout << "Please enter a valid integer" <<endl;
						getline(cin, input);
					}
					int invNum = stoi(input);
					//comparisons between the current room and what you're using will be made here
					if (invNum >= 0 && invNum <= Inv.getTableSize()) {
						//Add item to room inventory or use in puzzle
						if (Inv.searchItemNum(invNum) == "") {
                            system("CLS");
							cout << "There is nothing in that slot" << flush << endl;
							Score++;
						} else {
						    system("CLS");
							cout << "Used " << Inv.searchItemNum(invNum) << flush << endl;
							cout << endl;
							if(CurrentRoom->name == "Dining Room" && Inv.searchItemNum(invNum) == "Bottle of Acid"){
                                cout << "You melt the lock on the safe and find a key labeled: Back Door" << endl;
                                cout << "Nice!" << endl;
                                Map.search("Back Door")->locked = false;
                                Inv.deleteItem(invNum);
							}else if(CurrentRoom->name == "Dining Room" && Inv.searchItemNum(invNum) == "Knife"){
                                cout << "You pry open an Oyster with your knife to find a single shining Pearl inside" << endl;
                                cout << "that's kinda like a gem, right?" << endl;
                                Map.search("Dining Room")->items.push_back(Pearl);
                                Inv.deleteItem(invNum);
							}else if(CurrentRoom->name == "Shed" && Inv.searchItemNum(invNum) == "Wand"){
							    cout << "You use the wand and cast a spell which opens the hatch." << endl;
							    cout << "There is a ladder that leads down into a dark room." << endl;
							    Map.search("Basement")->locked = false;
							    Inv.deleteItem(invNum);
                            }else if(CurrentRoom->name == "Basement" && Inv.searchItemNum(invNum) == "Candle"){
                                cout << "You light the candle and find that there is a large mound of dirt" << endl;
                                cout << "in the once dark corner, I wonder what's under it?" << endl;
                                seen = true;
                                Inv.deleteItem(invNum);
                            }else if(CurrentRoom->name == "Basement" && Inv.searchItemNum(invNum) == "Shovel" && seen == true){
                                cout << "You dig up the mound of dirt in the corner" << endl;
                                cout << "after a while you find a Gem buried underneath...neat!" << endl;
                                Map.search("Basement")->items.push_back(Ruby);
                                Inv.deleteItem(invNum);
                            }else if(CurrentRoom->name == "Garden" && Inv.searchItemNum(invNum) == "Scythe"){
                                cout << "Using the scythe you cut the vines off of the chest in the corner." << endl;
                                cout << "Inside the chest there was a Step Ladder and a gleaming Emerald." <<endl;
                                Map.search("Garden")->items.push_back(Ladder);
                                Map.search("Garden")->items.push_back(Emerald);
                                Map.search("Garden")->puzSolved = true;
                                Inv.deleteItem(invNum);
                            }else if(CurrentRoom->name == "Fountain" && Inv.searchItemNum(invNum) == "Step Ladder"){
                                cout << "You use the step ladder to get to the top part of the fountain." << endl;
                                cout << "There is a small Sapphire sitting in the basin." << endl;
                                Map.search("Fountain")->items.push_back(Sapphire);
                                Map.search("Fountain")->puzSolved = true;
                                Inv.deleteItem(invNum);
                            }else if(CurrentRoom->name == "Foyer" && Inv.searchItemNum(invNum) == "Bat"){
                                cout << "You throw the Bat at the chandelier and glass rains down." << endl;
                                cout << "After you finish shielding your eyes from the glass you look back," << endl;
                                cout << "a shining Diamond sits in the middle of the room surrounded by glass." << endl;
                                Map.search("Foyer")->items.push_back(Diamond);
                                Map.search("Foyer")->items.push_back(Glass);
                                Inv.deleteItem(invNum);
                            }else if(CurrentRoom->name == "Entrance" && Inv.searchItemNum(invNum) == "Glass"){
                                cout << "Using the glass you reflect the light from the window onto the painting of the sun." << endl;
                                cout << "The painting opens it's mouth revealing a hidden compartment with a Flashlight and a small Amethyst." << endl;
                                cout << "Nice one!" << endl;
                                Map.search("Entrance")->items.push_back(Amethyst);
                                Map.search("Entrance")->items.push_back(Flashlight);
                                Inv.deleteItem(invNum);
                            }else if(CurrentRoom->name == "Study" && Inv.searchItemNum(invNum) == "Flashlight"){
                                cout << "Using the flashlight you can see behind the bookshelves." << endl;
                                cout << "There is a small crystal that seems to pulse with an other worldly glow." << endl;
                                CurrentRoom->puzSolved = true;
                                Map.search("Study")->items.push_back(Magic);
                                Inv.deleteItem(invNum);
                            }else if(CurrentRoom->name == "Study" && Inv.searchItemNum(invNum) == "Candle"){
                                cout << "You wouldn't want to light the books on fire....right!?" << endl;
                            }else if(CurrentRoom->name == "Gate"){
                                if(Inv.searchItemNum(invNum) == "Ruby" || Inv.searchItemNum(invNum) == "Sapphire" || Inv.searchItemNum(invNum) == "Emerald" || Inv.searchItemNum(invNum) == "Diamond" || Inv.searchItemNum(invNum) == "Amethyst" || Inv.searchItemNum(invNum) == "Magic Crystal" || Inv.searchItemNum(invNum) == "Diamond" || Inv.searchItemNum(invNum) == "Amethyst" || Inv.searchItemNum(invNum) == "Pearl"){
                                    cout << "Where would you like to put it?" << endl;
                                    //print the tree
									puzzleTree.print2DUtil(1);
                                    getline(cin,in);
									badInt:
                                    while(checkInt(in) == 0){
                                        cout << "Please enter a valid slot" <<endl;
                                        getline(cin, in);
                                    }
									if(checkInt(in) == 1){
										if(stoi(in) > 7 || stoi(in) < 0){
													cout << "Number outside of range" <<endl;
													in = "notAnInt";
													goto badInt;
										}
									}
                                    int slotChoice = stoi(in);
									if(puzzleTree.insertGem(slotChoice, Inv.searchItemNum(invNum)) == true){
										Inv.deleteItem(invNum);
									}
									puzzleTree.print2DUtil(1);
									//compare.print2DUtil(1);
									puzzleTreeVector.clear();
									compareTreeVector.clear();
									puzzleTreeVector = puzzleTree.treeToVector();
									compareTreeVector = compare.treeToVector();
									if(puzzleTreeVector == compareTreeVector){
										//win
										Map.search("Escape")->locked = false;
										cout << "The Gate opens Revealing your Escape!" << endl;
									}
                                    //put it into the tree
                                }
                            }else{
                                cout << "You can't use that here" << endl;
							}

						}

					} else {
					    system("CLS");
						cout << "Number is outside of table size" << flush << endl;
					}

                }else if(input == "quit"){
                    key = false;
                    break;
                }else if(input == "drop"){
                    cout << "Choose an item to drop:" << endl;
					DisplayPlayerInventory(Inv);
					cout << endl;
					cout << "Enter the number of the inventory slot you want to drop." << endl;
                    cout << "you currently have: " << invSize << " slots" << endl;
					getline(cin, input);
					while(checkInt(input) == 0){
						cout << "Please enter a valid integer" <<endl;
						getline(cin, input);
					}
					int invNum = stoi(input);
                    if (Inv.searchItemNum(invNum) == "") {
                            system("CLS");
							cout << "There is nothing in that slot" << flush << endl;
							Score++;
                    }else{
                        system("CLS");
                        cout << "Dropped the " << Inv.searchItemNum(invNum) << flush << endl;
                        CurrentRoom->items.push_back(Inv.searchItemNum(invNum));
                        Inv.deleteItem(invNum);
                    }
                }else if(input == "help"){
                    cout << "List of Available Commands:" << endl;
                    cout << "help - you're using this one" << endl;
                    cout << "drop - drops a item from your inventory on the floor of the current room you're in" << endl;
                    cout << "take - take an item from the room you are currently in and add it to your inventory" << endl;
                    cout << "use - use an item from your inventory by entering which slot it is in, (the hash function is: Name % " << invSize << ")" <<endl;
                    cout << "quit - ends the game" << endl;
                    cout << endl;
                    cout << "Type the name of an adjacent room to go there" << endl;
                    cout << endl;
                    cout << "This game was made by Bobby Ford and Joshua Dinerman for their Data Structure's choose your own project :)" << endl;
                }else if(input == "remove" && CurrentRoom->name == "Gate"){
                    cout << "What will you take out of the gate?" << endl;
                    //code to remove from the gate
					puzzleTree.print2DUtil(1);
					cout << "Please enter the slot number of what you would like to remove:" << endl;
					string toInsert = "";
					int removeChoice = 0;
					while(toInsert == ""){
                    getline(cin,input);
						while(checkInt(input) == 0){
							cout << "Please enter a valid integer" <<endl;
							getline(cin, input);
						}
					removeChoice = stoi(input);
					toInsert = puzzleTree.removeGem(removeChoice);
					}
					Inv.insertItem(toInsert);
					puzzleTree.print2DUtil(1);
                }else{
                    cout << "You can't do that here" << endl;
                }
            }else{
                //this is used for if a room that is locked trying to be entered
                cout << "That room is locked" << endl;
            }
            DisplayRooms(CurrentRoom);
            getline(cin,input);
        }
        CurrentRoom = Map.searchAdj(input,CurrentRoom);
        system("CLS");
        cout << "---------------------------" << flush << endl;
        cout << endl;
    }
    if(End == false){
        system("CLS");
        cout << "---------------------------" << flush << endl;
        cout << endl;
        cout << "See yah!" << flush << endl;
        cout << endl;
        cout << "---------------------------" << endl;
    }
}
