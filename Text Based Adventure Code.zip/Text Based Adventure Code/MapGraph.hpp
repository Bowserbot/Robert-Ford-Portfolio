#ifndef GRAPH_H
#define GRAPH_H
#include<vector>
#include<iostream>
using namespace std;

struct vertex;
struct adjVertex{
    vertex *v;
};

struct item{
    string name;
    int value;
};

struct vertex{
    vertex() {
        this->visited = false;
        this->distance = 0;
        this->locked = false;
        this->itemHere = false;
        this->puzSolved = false;
    }
    string name;
    bool visited;
    bool locked;
    bool itemHere;
    bool puzSolved;
    int distance;
    vector<adjVertex> adj;
    vector<string> items;
};

class Graph
{
    public:
        void addEdge(string v1, string v2);
        void addVertex(string name);
        void displayEdges();
        int getConnectedComponents();
        vertex* initialRoom();
        vertex* search(string);
        vertex* searchAdj(string,vertex*);
        int searchItems(string,vertex*);

    private:
        vector<vertex*> vertices;
};

#endif // GRAPH_H
